module Practices {
    requires java.desktop;
    requires java.logging;
    requires jdk.scripting.nashorn;
}